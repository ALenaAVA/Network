-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Дек 24 2020 г., 12:32
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `s91941yy_mydb`
--

-- --------------------------------------------------------

--
-- Структура таблицы `attachments`
--
-- Создание: Июл 11 2020 г., 15:41
--

DROP TABLE IF EXISTS `attachments`;
CREATE TABLE `attachments` (
  `id` int(11) NOT NULL,
  `id_post` int(11) NOT NULL,
  `name_file` varchar(255) NOT NULL,
  `checkPhoto` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `attachments`
--

INSERT INTO `attachments` (`id`, `id_post`, `name_file`, `checkPhoto`) VALUES
(2, 1, '02072020132806c65360a0974c013a8e13d5e7fee6d58b.png', '1'),
(3, 2, '020720201337267faa65bc9adb25f60b5b4b836c408e83.png', '1'),
(4, 2, '02072020133726c163c637e27411a34f912e93992315b7.png', '1'),
(5, 2, '02072020133726fd4aba97c1b32a643a1341dce86e04af.png', '1'),
(6, 2, '02072020133726c76c66edf30825631ef92dd04a09b114.png', '1'),
(7, 3, '020720201356348cffbee63b9acf9fa4091406b34a076c.png', '1'),
(8, 3, '020720201356342ceea1e37018d0210674001e12871010.png', '1'),
(9, 4, '020720201359561a10127400abb115b00b0fd6122d605b.png', '1'),
(10, 4, '020720201359569f602e3a716a1cb278cf25b986f41c3f.png', '1'),
(12, 7, '03072020090505dc924d96ecba9dd5cf22518e00e1db54.png', '1'),
(28, 10, '0307202015331466eb1533dc0c54b471f35c01c4a45aeb.png', '1'),
(33, 11, '0907202015033218481eebffab2177253474504442d95d.png', '1'),
(34, 12, '0907202016314571c39ab0b319c1fce0517231d4e09fe2.png', '1'),
(35, 12, '09072020163145d9a9cc75f66f228307476f32dd7ed6ab.png', '1'),
(36, 12, '09072020163145da724ef22652e1779438737b6ff42782.png', '1'),
(37, 13, '1007202011310989fef0ed5270a2a925b1ee5af22b6d8a.png', '1'),
(38, 13, '100720201131097ac64a188c54fac9fc4b7b4ec8e9b9e9.png', '1'),
(39, 14, '130720201440007aaa18395d2cf33417f658f181906207.png', '1'),
(40, 14, '13072020144000a08ebf199a1889a6e1fc9300d3f6bed7.png', '1'),
(41, 14, '130720201440002daa6c6d3b1d589cf183845db2247183.png', '1'),
(42, 14, '13072020144000018b3361187a30609f02ba37abfd78ab.png', '1'),
(43, 20, '17072020095334a04849b3ad49435708d10fa1d2d23bdd.png', '1'),
(44, 20, '1707202009533402774ecaccac6371c3bd609d7a3ad145.png', '1'),
(45, 20, '1707202009533495c1e90c40ebc0f8162a6f132ecc50f1.png', '1'),
(46, 20, '170720200953345ef6253b81615f10b14ec03a0ccb350d.png', '1'),
(47, 20, '170720200953346f420dec3d6b002e13786b977b283b14.png', '1'),
(48, 21, '17072020095457c44824d03b89e60dbc21d8e33fb90fac.png', '1'),
(49, 21, '1707202009545706e2128dd84d7220352cddbe90c884d5.png', '1'),
(50, 21, '170720200954575100dd7c34802a40887edcbe5d85b6fa.png', '1'),
(51, 21, '1707202009545773e85fc019e4b9f8105ecf52a20f0241.png', '1'),
(52, 22, '170720201341401e07775f293c82d56090f4b021933f1d.png', '0'),
(53, 22, '17072020134140411994596c07022fea71b9e35fa7ffb0.png', '0'),
(54, 22, '170720201341409f303426f196ecebb40ba9640d138f1c.png', '0'),
(55, 22, '17072020134140370021f6955f64c09bccdc34fa04cb2e.png', '0'),
(56, 25, '17072020201314e637f8efe7625126823ce7d11d2d130c.png', '0');

-- --------------------------------------------------------

--
-- Структура таблицы `friends`
--
-- Создание: Июл 10 2020 г., 14:49
--

DROP TABLE IF EXISTS `friends`;
CREATE TABLE `friends` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_user_1` int(11) NOT NULL,
  `id_user_2` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `friends`
--

INSERT INTO `friends` (`id`, `id_user_1`, `id_user_2`, `status`) VALUES
(3, 2, 5, 2),
(4, 2, 3, 2),
(5, 3, 5, 2),
(6, 4, 6, 2),
(8, 5, 4, 2),
(37, 6, 2, 2),
(38, 2, 4, 1),
(39, 2, 23, 1),
(40, 26, 2, 2),
(41, 2, 15, 1),
(42, 2, 14, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `insertion`
--
-- Создание: Июл 11 2020 г., 15:34
--

DROP TABLE IF EXISTS `insertion`;
CREATE TABLE `insertion` (
  `id` int(11) NOT NULL,
  `id_mes` int(11) NOT NULL,
  `name_file` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `insertion`
--

INSERT INTO `insertion` (`id`, `id_mes`, `name_file`) VALUES
(1, 1, '1007202017584371824a46f5973e0cab02b77785f28231.png'),
(2, 1, '10072020175843dcecc492a6162ac47168d3868ff208e0.png'),
(3, 2, '10072020175859e2998c53106137c8d73070e1f548aa9f.png'),
(4, 3, '10072020180025898d9b63592f3d1f0d3c500c52f813e8.png'),
(5, 3, '10072020180025d849ec58ac131bb6af8595a4ac8d02b7.png'),
(6, 4, '1007202018023769ad0af0c1a449ce9ecc36b9273e176b.png'),
(7, 5, '130720201007018ee58b7f3d74576b0c419b446c6d163b.png'),
(8, 5, '1307202010070108fb5191c98bc130942ac300b9d0ba68.png'),
(9, 5, '13072020100701ddbc3c1bfd559f305662356c2790b651.png');

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--
-- Создание: Июл 10 2020 г., 14:49
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `sender` int(11) NOT NULL,
  `recipient` int(11) NOT NULL,
  `date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `messages`
--

INSERT INTO `messages` (`id`, `sender`, `recipient`, `date`, `time`, `text`) VALUES
(1, 2, 15, '10.07.2020', '17:58', 'Привет'),
(2, 2, 15, '10.07.2020', '17:58', 'Как дела?'),
(3, 2, 6, '10.07.2020', '18:00', 'Привет'),
(4, 15, 2, '10.07.2020', '18:02', 'Хорошо'),
(5, 26, 2, '13.07.2020', '10:07', 'Привет'),
(6, 3, 2, '17.07.2020', '09:55', 'Привет'),
(7, 2, 3, '17.07.2020', '09:56', 'Hello'),
(8, 3, 2, '17.07.2020', '09:57', 'Как дела?'),
(9, 2, 3, '17.07.2020', '09:57', 'У меня все супер!!!'),
(10, 2, 15, '17.07.2020', '13:43', 'Привет'),
(11, 2, 30, '17.07.2020', '13:57', 'Привет'),
(12, 30, 2, '17.07.2020', '13:57', 'Привет'),
(13, 2, 6, '18.07.2020', '11:14', 'орпорпор');

-- --------------------------------------------------------

--
-- Структура таблицы `notifications`
--
-- Создание: Июл 11 2020 г., 12:37
--

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_from` int(11) NOT NULL,
  `id_to` int(11) NOT NULL,
  `text` text NOT NULL,
  `date` varchar(20) NOT NULL,
  `time` varchar(10) NOT NULL,
  `viewed` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `notifications`
--

INSERT INTO `notifications` (`id`, `id_from`, `id_to`, `text`, `date`, `time`, `viewed`) VALUES
(1, 2, 15, 'Пользователь <a href = \"/network3/@totoro\">Александра Заворотняя</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(2)\">', '10.07.2020', '17:58', '1'),
(2, 2, 15, 'Пользователь <a href = \"/network3/@totoro\">Александра Заворотняя</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(2)\">', '10.07.2020', '17:58', '1'),
(3, 2, 23, 'Пользователь <a class=\"pjax-page-link\" onclick=\"go(this, event,function(){$(\'#notifications .list\').html(\'\')})\" href = \"/network3/@totoro\">Александра Заворотняя</a> хочет добавить Вас в друзья.', '10.07.2020', '17:59', '0'),
(4, 2, 6, 'Пользователь <a href = \"/network3/@totoro\">Александра Заворотняя</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(2)\">', '10.07.2020', '18:00', '0'),
(5, 15, 2, 'Пользователь <a href = \"/network3/@totoro12\">Юлия Акименко</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(15)\">', '10.07.2020', '18:02', '1'),
(6, 26, 2, 'Пользователь <a href = \"/network3/@apostol\">Владимир Апостолов</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(26)\">', '13.07.2020', '10:07', '1'),
(7, 26, 2, 'Пользователь <a class=\"pjax-page-link\" onclick=\"go(this, event,function(){$(\'#notifications .list\').html(\'\')})\" href = \"/network3/@apostol\">Владимир Апостолов</a> хочет добавить Вас в друзья.', '13.07.2020', '10:07', '1'),
(8, 2, 26, 'Заявка в друзья принята. Теперь <a class =\"pjax-page-link\" onclick=\"go(this, event,function(){$(\'#notifications .list\').html(\'\')})\" href = \"/network3/@totoro\">Александра Заворотняя</a> Ваш друг.', '16.07.2020', '14:03', '0'),
(9, 3, 2, 'Пользователь <a href = \"/network3/@totoro2\">Виталина Григорук</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(3)\">', '17.07.2020', '09:55', '1'),
(10, 2, 3, 'Пользователь <a href = \"/network3/@totoro\">Александра Заворотняя</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(2)\">', '17.07.2020', '09:56', '1'),
(11, 3, 2, 'Пользователь <a href = \"/network3/@totoro2\">Виталина Григорук</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(3)\">', '17.07.2020', '09:57', '1'),
(12, 2, 3, 'Пользователь <a href = \"/network3/@totoro\">Александра Заворотняя</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(2)\">', '17.07.2020', '09:57', '1'),
(13, 2, 15, 'Пользователь <a href = \"/network3/@totoro\">Александра Заворотняя</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(2)\">', '17.07.2020', '13:43', '0'),
(14, 2, 15, 'Пользователь <a class=\"pjax-page-link\" onclick=\"go(this, event,function(){$(\'#notifications .list\').html(\'\')})\" href = \"/network3/@totoro\">Александра Заворотняя</a> хочет добавить Вас в друзья.', '17.07.2020', '13:45', '0'),
(15, 2, 14, 'Пользователь <a class=\"pjax-page-link\" onclick=\"go(this, event,function(){$(\'#notifications .list\').html(\'\')})\" href = \"/network3/@totoro\">Александра Заворотняя</a> хочет добавить Вас в друзья.', '17.07.2020', '13:46', '0'),
(16, 2, 30, 'Пользователь <a href = \"/network3/@totoro\">Александра Заворотняя</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(2)\">', '17.07.2020', '13:57', '1'),
(17, 30, 2, 'Пользователь <a href = \"/network3/@ivan\">Иванов Иван</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(30)\">', '17.07.2020', '13:57', '1'),
(18, 2, 6, 'Пользователь <a href = \"/network3/@totoro\">Александра Заворотняя</a> \n    отправил(а) Вам сообщение <img src=\"public/img/menu/messages.png\" alt=\"\" title=\"Написать сообщение\" onclick=\"APP.window.form.messagesContainer(2)\">', '18.07.2020', '11:14', '0');

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--
-- Создание: Июл 11 2020 г., 11:03
--

DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `date` varchar(255) CHARACTER SET utf8 NOT NULL,
  `time` varchar(10) CHARACTER SET utf8 NOT NULL,
  `text` text CHARACTER SET utf8 NOT NULL,
  `id_author` int(11) NOT NULL,
  `id_page` int(11) NOT NULL,
  `attachment` text CHARACTER SET utf8
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `date`, `time`, `text`, `id_author`, `id_page`, `attachment`) VALUES
(1, '02.07.2020', '14:28:06', 'Китайцы убеждены: этот цветок растёт не только на земле, но и на небе, в раю. Лотосы, украшающие райские озёра, в действительности являются душами людей. Растения, в которых воплотились праведные души, всегда цветут и благоухают, а лотосы, в которых оказались грешники, вянут быстро: климат рая им категорически не подходит.', 2, 2, NULL),
(2, '02.07.2020', '14:37:26', 'Как приятно после холодной и долгой зимы почувствовать теплые солнечные лучи. Море - это всегда радость, удовольствие, время релакса и одно из самых излюбленных видов отдыха современного человека. Теплый песок и лазурные воды... что может быть лучше после душных объятий города?\nВо все времена года море необыкновенно красивое, отражая в себе небо, оно излучает некую доброту, которая манит. Не зря людей всегда тянет к морю, ведь его удивительной красотой нельзя не восхищаться!\nМы приглашаем вас к морю, выбор велик и многообразен, но вместе нам удастся подобрать, именно, ваше место у моря.', 2, 2, NULL),
(3, '02.07.2020', '14:56:33', 'Научное название Matricaria идет от слова matrix (лат. «матка»). Связано это с тем, что изначально ромашки применяли для лечения всевозможных гинекологических заболеваний.\n\nСамое удивительное, что до того, как появилось название «ромашка», существовало огромное множество названий для этих цветов, а после них все начали называть ромашками даже те цветы, которые ромашками не являются. Но об этом читайте ниже.', 4, 4, NULL),
(4, '02.07.2020', '14:59:56', 'Наверное, не встретишь человека, который был бы равнодушен к горам. Ведь высоко чувствуешь себя свободным, словно птица. Именно там можно дышать полной грудью. Горы удивляют своим могуществом, неприступностью, неповторимыми пейзажами.\nЧем же людей влекут горы? Безусловно, своей красотой, высокими и отвесными утёсами, удивительной природой, вечными снегами на вершинах, воздухом, которым невозможно надышатся... Это целый мир - чудный, завораживающий, опасный, но манящий. Разгадать, разведать, что скрывается за тем перевалом, в том ущелье, у этой вершины... Дух захватывает, когда ты поднимаешься высоко в горы! Смотришь сверху вниз на тонкие ленты рек и дорог, на ровные очертания посёлков, на цветущие сады...Когда над тобой или на уровне вытянутой руки проплывают облака - это незабываемые ощущения. Весь мир  у твоих ног! Стоит только раз побывать в горах и ты навсегда оставишь там частичку своего сердца.\nПредлагаем и вам покорить одну из вершин. Все горы планеты к вашим услугам!', 2, 4, NULL),
(10, '03.07.2020', '16:33:14', 'Белки — очень шустрые и безмерно любопытные зверьки. Каждый посетитель, задержавшийся у их вольере, становится объектом беличьего внимания. Наши белочки дружелюбны и вполне хорошо уживаются с морскими свинками, с которыми делят вольер в летний период. Любят орехи, фрукты, ягоды. Запасов никогда не делают, так как корм получают ежедневно.', 5, 2, NULL),
(11, '09.07.2020', '16:03:31', 'История тыквы\nПо некоторым источникам, уже 5,5-8 тысяч лет назад ее активно выращивали. В Европу тыква была завезена из Южной Америки, и быстро заняла важное место в кулинарии и даже медицине. В современном мире для нас она просто вкусный и красивый овощ, но изначальное отношения к тыкве было несколько иным: она считалась сырьем для изготовления лечебных средств.', 2, 2, NULL),
(12, '09.07.2020', '17:31:45', 'Фантастика рассказывает о том, что находится за гранью реальности, и строится на фантастическом допущении. Она включает в себя множество жанров и поджанров, начиная от антиутопий и научной фантастики и заканчивая фэнтези и магическим реализмом.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n', 2, 2, NULL),
(13, '10.07.2020', '12:31:09', 'История тыквы По некоторым источникам, уже 5,5-8 тысяч лет назад ее активно выращивали. В Европу тыква была завезена из Южной Америки, и быстро заняла важное место в кулинарии и даже медицине. В современном мире для нас она просто вкусный и красивый овощ, но изначальное отношения к тыкве было несколько иным: она считалась сырьем для изготовления лечебных средств.', 15, 15, NULL),
(14, '13.07.2020', '14:40:00', 'Тебе желаю море счастья,\nУлыбок, солнца и тепла.\nЧтоб жизнь была еще прекрасней,\nУдача за руку вела!\n\nПусть в доме будет только радость,\nУют, достаток и покой.\nДрузья, родные будут рядом,\nБеда обходит стороной!', 2, 15, NULL),
(21, '17.07.2020', '09:54:57', 'Белки — очень шустрые и безмерно любопытные зверьки. Каждый посетитель, задержавшийся у их вольере, становится объектом беличьего внимания. Наши белочки дружелюбны и вполне хорошо уживаются с морскими свинками, с которыми делят вольер в летний период. Любят орехи, фрукты, ягоды. Запасов никогда не делают, так как корм получают ежедневно.', 3, 3, NULL),
(22, '17.07.2020', '13:41:40', 'Автомоби́ль (от др.-греч. αὐτός — сам и лат. mobilis — подвижной, скорый), \nСамодвижущийся экипаж[1] — моторное дорожное и вне дорожное транспортное \nсредство, используемое для перевозки людей или грузов.\n\nОсновное назначение автомобиля заключается в совершении транспортной \nработы[2]. Автомобильный транспорт в промышленно развитых странах занимает\n ведущее место по сравнению с другими видами транспорта по\n объёму перевозок пассажиров[3]. Современный автомобиль состоит\n из 15—20 тысяч деталей, из которых 150—300 являются наиболее важными и \nтребующими наибольших затрат в эксплуатации[4]. Понятие включает \nлегковой автомобиль, грузовой автомобиль, автобус, троллейбус, \nбронетранспортёр, но не включает сельскохозяйственный трактор и мотоцикл.', 2, 2, NULL),
(23, '17.07.2020', '13:54:41', 'Hello', 30, 30, NULL),
(24, '17.07.2020', '13:54:56', 'Hello2', 30, 30, NULL),
(25, '17.07.2020', '20:13:14', 'Привет!!!', 31, 31, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Июл 10 2020 г., 14:50
-- Последнее обновление: Июл 18 2020 г., 08:18
-- Последняя проверка: Июл 11 2020 г., 14:50
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(40) NOT NULL,
  `surname` varchar(40) NOT NULL,
  `birthday` varchar(12) NOT NULL,
  `birthmonth` varchar(50) NOT NULL,
  `birthyear` varchar(11) NOT NULL,
  `sex` enum('0','1') NOT NULL,
  `avatar` varchar(255) NOT NULL DEFAULT 'no-avatar.png',
  `banner` varchar(255) NOT NULL DEFAULT 'no-banner.png',
  `path` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `maritalStatus` varchar(100) DEFAULT NULL,
  `showBirthday` int(1) DEFAULT '1',
  `lastVisit` varchar(255) NOT NULL DEFAULT '0',
  `online` enum('0','1') NOT NULL DEFAULT '0',
  `role` enum('0','1','2') NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `password`, `name`, `surname`, `birthday`, `birthmonth`, `birthyear`, `sex`, `avatar`, `banner`, `path`, `city`, `maritalStatus`, `showBirthday`, `lastVisit`, `online`, `role`) VALUES
(2, 'totoro', 'alenaava@rambler.ru', '$2y$10$EsPS.G03wcB9eIr0q2fuVe5UZ0TSHGgnactxfK0y1WjCNbvCenata', 'Александра', 'Заворотняя', '4', '1', '1997', '1', '18072020111546c81e728d9d4c2f636f067f89cc14862c.png', '18072020111511c81e728d9d4c2f636f067f89cc14862c.png', 'totoro', NULL, NULL, 1, '18.07.2020 11:17', '0', '0'),
(3, 'totoro2', 'alenaava1@rambler.ru', '$2y$10$EsPS.G03wcB9eIr0q2fuVe5UZ0TSHGgnactxfK0y1WjCNbvCenata', 'Виталина', 'Григорук', '12', '6', '1986', '1', '10072020160048eccbc87e4b5ce2fe28308fd9f2a7baf3.png', '02072020132614eccbc87e4b5ce2fe28308fd9f2a7baf3.png', 'totoro2', NULL, NULL, 1, '17.07.2020 10:08', '0', '0'),
(4, 'totoro4', 'alenaava12@rambler.ru', '$2y$10$EsPS.G03wcB9eIr0q2fuVe5UZ0TSHGgnactxfK0y1WjCNbvCenata', 'Виталий', 'Литвиненко', '12', '6', '1970', '0', '10072020154819a87ff679a2f3e71d9181a67b7542122c.png', '03072020153556a87ff679a2f3e71d9181a67b7542122c.png', 'totoro4', NULL, NULL, 1, '16.07.2020 14:47', '0', '0'),
(5, 'totoro3', 'alenaava1234@rambler.ru', '$2y$10$EsPS.G03wcB9eIr0q2fuVe5UZ0TSHGgnactxfK0y1WjCNbvCenata', 'Виктор', 'Опанасенко', '12', '6', '1998', '0', '16072020144717e4da3b7fbbce2345d7772b0674a318d5.png', '22062020143338e4da3b7fbbce2345d7772b0674a318d5.png', 'totoro3', NULL, NULL, 1, '16.07.2020 14:47', '0', '0'),
(6, 'totoro5', 'alenaava1266@rambler.ru', '$2y$10$EsPS.G03wcB9eIr0q2fuVe5UZ0TSHGgnactxfK0y1WjCNbvCenata', 'Юлия', 'Жукова', '12', '6', '2001', '1', '020720201318401679091c5a880faf6fb5e6087eb1b2dc.png', '020720201325271679091c5a880faf6fb5e6087eb1b2dc.png', 'totoro5', NULL, NULL, 1, '16.07.2020 14:47', '0', '0'),
(13, 'totoro10', 'alenaava123@rambler.ru', '$2y$10$EsPS.G03wcB9eIr0q2fuVe5UZ0TSHGgnactxfK0y1WjCNbvCenata', 'Виктор', 'Носаль', '7', '7', '1954', '0', '16072020144852c51ce410c124a10e0db5e4b97fc2af39.png', '16072020145214c51ce410c124a10e0db5e4b97fc2af39.png', 'totoro10', NULL, NULL, 1, '16.07.2020 14:52', '0', '0'),
(14, 'totoro11', 'lhuyrnzg@zeroe.ml', '$2y$10$EsPS.G03wcB9eIr0q2fuVe5UZ0TSHGgnactxfK0y1WjCNbvCenata', 'Виталина', 'Акименко', '7', '7', '1990', '1', '16072020145331aab3238922bcc25a6f606eb525ffdc56.png', '16072020145301aab3238922bcc25a6f606eb525ffdc56.png', 'totoro11', NULL, NULL, 1, '16.07.2020 14:53', '0', '0'),
(15, 'totoro12', 'nflbkozg@zeroe.ml', '$2y$10$EsPS.G03wcB9eIr0q2fuVe5UZ0TSHGgnactxfK0y1WjCNbvCenata', 'Юлия', 'Акименко', '7', '8', '1989', '1', '100720201738229bf31c7ff062936a96d3c8bd1f8f2ff3.png', '100720201415159bf31c7ff062936a96d3c8bd1f8f2ff3.png', 'totoro12', NULL, NULL, 1, '16.07.2020 14:38', '0', '0'),
(1, 'admin', 'gontarenko.alena@gmail.com', '$2y$10$WV2PuU4HZ2odjBSdZwCjaOpxty/nBqyC5XH6J97OWw5JwMgLuGWs.', 'admin', 'admin', '9', '7', '1988', '0', 'no-avatar.png', 'no-banner.png', 'admin', NULL, NULL, 1, '17.07.2020 13:31', '0', '2'),
(23, 'totoro99', 'o8ygb@vmani.com', '$2y$10$8RxKmllSLOWScH1rSPucyOWvCH7HuPnvwx7Ayo9V5U/0GseuzoihS', 'Алеся', 'Тутова', '10', '2', '1994', '1', '1007202015524437693cfc748049e45d87b8c7d8b9aacd.png', '1007202015522937693cfc748049e45d87b8c7d8b9aacd.png', 'totoro99', NULL, NULL, 1, '16.07.2020 14:38', '0', '0'),
(22, 'totoro88', 'letoja8827@mailerv.net', '$2y$10$8RxKmllSLOWScH1rSPucyOWvCH7HuPnvwx7Ayo9V5U/0GseuzoihS', 'Виктория', 'Стадная', '9', '8', '1985', '1', '16072020144059b6d767d2f8ed5d21a44b0e5886680cb9.png', 'no-banner.png', 'totoro88', NULL, NULL, 1, '16.07.2020 14:41', '0', '0'),
(24, 'petichkin', 'nedihe4157@mailerv.net', '$2y$10$RBiCJwnObJ2.h6Pmbnv5n.QCvEA.CRgvvjL1ZjWiYzHSLrPs50tSC', 'Андрей', 'Петичкин', '16', '10', '1960', '0', 'no-avatar.png', 'no-banner.png', 'petichkin', NULL, NULL, 1, '10.07.2020 16:30', '0', '0'),
(25, 'sabina', 'sanya@ageokfc.com', '$2y$10$fnVw4XiGyBO67igTU9g9SOgneFZg.Gd3zvK2jF0rhsabic9zG228G', 'Сабина', 'Петрушка', '16', '7', '1999', '1', 'no-avatar.png', 'no-banner.png', 'sabina', NULL, NULL, 1, '12.07.2020 19:05', '0', '0'),
(26, 'apostol', 'fu77p@vmani.com', '$2y$10$FsAIlbzaLGqgoEcNk69c9e/LBmCAgN.zWmi.xx5Gk1as1hwSBInF2', 'Владимир', 'Апостолов', '13', '7', '1987', '0', '130720201005554e732ced3463d06de0ca9a15b6153677.png', '130720201005414e732ced3463d06de0ca9a15b6153677.png', 'apostol', NULL, NULL, 1, '13.07.2020 10:10', '0', '0'),
(27, 'sunset', 'wfokcabt@yomail.info', '$2y$10$8RxKmllSLOWScH1rSPucyOWvCH7HuPnvwx7Ayo9V5U/0GseuzoihS', 'Anet', 'Smit', '13', '9', '2001', '1', '1607202014541402e74f10e0327ad868d138f2b4fdd6f0.png', '1607202014510602e74f10e0327ad868d138f2b4fdd6f0.png', 'sunset', NULL, NULL, 1, '16.07.2020 14:54', '0', '0'),
(28, 'stepan', 'vulmarirtu@enayu.com', '$2y$10$LnTwp3CfSzVnPqujU8dD2erGhic1MvborGpPboPI5ToqAU02k1kR.', 'Степан', 'Клименко', '2', '7', '1982', '0', '1707202009324833e75ff09dd601bbe69f351039152189.png', '1707202009342733e75ff09dd601bbe69f351039152189.png', 'stepan', NULL, NULL, 1, '17.07.2020 09:34', '0', '0'),
(29, 'ula', 'c3jv6@vmani.com', '$2y$10$7FJ8KoZFT6EcrhdRzgeMTecQC.G0.Uu1tzE225OTkj7GExQiLK7JS', 'Юлия', 'Степаненко', '17', '8', '2020', '1', 'no-avatar.png', 'no-banner.png', 'ula', NULL, NULL, 1, '17.07.2020 10:02', '1', '0'),
(30, 'ivan', 'pkm73@vmani.com', '$2y$10$6e.cMKiONEXzKN1hu//Kce./lVQi3U9Q5BnXThz5626oBrobc6pMq', 'Иванов', 'Иван', '17', '7', '2001', '0', 'no-avatar.png', 'no-banner.png', 'ivan', NULL, NULL, 1, '17.07.2020 13:49', '1', '0'),
(31, 'Vita', 'vita.napadaylo@gmail.com', '$2y$10$nPXaSOlgLKS8c8.gWfYWQezW5cO7jnUBFLmCiXYw5OZe.W0z8R3hC', 'Виктория', 'Ник', '17', '7', '2020', '0', 'no-avatar.png', 'no-banner.png', 'Vita', NULL, NULL, 1, '18.07.2020 00:08', '1', '0');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `attachments`
--
ALTER TABLE `attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_post` (`id_post`);

--
-- Индексы таблицы `friends`
--
ALTER TABLE `friends`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `insertion`
--
ALTER TABLE `insertion`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_mes` (`id_mes`);

--
-- Индексы таблицы `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `users` ADD FULLTEXT KEY `name` (`name`,`surname`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `attachments`
--
ALTER TABLE `attachments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT для таблицы `friends`
--
ALTER TABLE `friends`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT для таблицы `insertion`
--
ALTER TABLE `insertion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT для таблицы `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT для таблицы `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
